import { useState } from "react";
import LoginScreen from "@/components/login-screen";
import ChatInterface from "@/components/chat-interface";
import TerminalIntro from "@/components/terminal-intro";
import PasswordDialog from "@/components/password-dialog";
import { useWebSocket } from "@/hooks/use-websocket";

export default function Home() {
  const [showIntro, setShowIntro] = useState(true);
  const [isInChat, setIsInChat] = useState(false);
  const { 
    socket, 
    isConnected, 
    roomData, 
    messages, 
    users, 
    error, 
    needsPassword,
    pendingRoomData,
    joinRoom, 
    sendMessage, 
    sendCommand, 
    leaveRoom,
    clearPasswordPrompt
  } = useWebSocket();

  const handleJoinRoom = (username: string, seed: string) => {
    joinRoom(username, seed);
  };

  const handlePasswordSubmit = (password: string) => {
    if (pendingRoomData) {
      joinRoom(pendingRoomData.username, pendingRoomData.seed, password);
    }
  };

  const handleLeaveRoom = () => {
    leaveRoom();
    setIsInChat(false);
  };

  // Set isInChat to true when successfully joined
  if (roomData && !isInChat) {
    setIsInChat(true);
  }

  return (
    <div className="min-h-screen bg-fox-bg text-fox-text">
      {showIntro ? (
        <TerminalIntro onComplete={() => setShowIntro(false)} />
      ) : !isInChat ? (
        <LoginScreen onJoinRoom={handleJoinRoom} error={error} />
      ) : (
        <ChatInterface
          roomData={roomData}
          messages={messages}
          users={users}
          isConnected={isConnected}
          onSendMessage={sendMessage}
          onSendCommand={sendCommand}
          onLeaveRoom={handleLeaveRoom}
          error={error}
        />
      )}

      {/* Password Dialog */}
      <PasswordDialog
        isOpen={needsPassword}
        onSubmit={handlePasswordSubmit}
        onCancel={clearPasswordPrompt}
        roomSeed={pendingRoomData?.seed || ""}
      />
    </div>
  );
}
